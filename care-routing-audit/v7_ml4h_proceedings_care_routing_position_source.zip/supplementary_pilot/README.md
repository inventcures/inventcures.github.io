# Synthetic care-routing audit pilot

Companion material for an anonymous ML4H 2026 submission. Everything is synthetic: no real clinics, patients or platforms. US payer plan names are used only as labels.

- `index.html` is the interactive report and works offline.
- `math/index.html` walks through every audit quantity for one patient, using the synthetic numbers.
- `code/` holds the pilot scripts (Python standard library only). Models are called through OpenRouter. The scripts read an API key from `~/.openrouter_key`, which is not included.
- `data/` holds the per-episode records (including every tool call), the affiliation trials, the generated world and the summaries for each run. `results_v3_us_final` and `results_v3_senior` are the main three-model runs.

Reproduce:

    cd code
    python3 routing_pilot_us_v3.py run --mock --out results_mock        # no API calls
    python3 routing_pilot_us_v3.py run --models "google/gemini-3.1-flash-lite,openai/gpt-6.1-sol@low,anthropic/claude-sonnet-5.5@medium" --services breast_diagnostic,diabetes_followup --out results_us
    python3 make_report.py "US=results_us" --out report.html
