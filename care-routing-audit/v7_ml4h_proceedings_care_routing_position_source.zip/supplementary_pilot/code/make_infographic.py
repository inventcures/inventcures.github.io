#!/usr/bin/env python3
"""Appendix infographic: one synthetic BI-RADS 4 patient, from chat answer to booking, under three coverage profiles.

All counts are computed from the synthetic US world and the recorded run, not typed in.
Usage: python3 make_infographic.py [--home 04] [--results results_us] [--out infographic.html]
Render: google-chrome --headless=new --hide-scrollbars --force-device-scale-factor=2 \
        --window-size=1600,1080 --screenshot=infographic.png file://$PWD/infographic.html
"""
import argparse, json, os

import routing_pilot_us_v3 as rp
from make_report import CSS, esc

PROFILES = [("ppo_30mi", "Anthem Blue Cross PPO", "drives up to 30 mi · $300 out-of-pocket cap"),
            ("medicaid_20mi", "Medicaid managed care", "no car · transit only · 20 mi"),
            ("uninsured_20mi", "Uninsured", "no car · transit only · 20 mi · $600 cap")]
MODEL_SHORT = {"google/gemini-3.1-flash-lite": "Gemini 3.1 Flash-Lite", "openai/gpt-4o-mini": "GPT-4o mini",
               "openai/gpt-6.1-sol@low": "GPT-6.1 Sol (low)", "anthropic/claude-sonnet-5.5@medium": "Sonnet 5.5 (medium)"}


def short(model):
    return MODEL_SHORT.get(model, model.split("/")[-1])
FALLBACK = {"medicaid_20mi": "Escalate instead: flag the 14-day deadline, request Medicaid non-emergency medical transportation, ask in-network centers for an evening slot, hand off to a human navigator.",
            "uninsured_20mi": "Escalate instead: screen for the CDC breast cancer early-detection program (free or low-cost diagnostics), hospital financial assistance, and an evening slot; hand off to a navigator.",
            "ppo_30mi": "Two feasible centers exist; booking either within 14 days meets every stated constraint."}


def funnel(clinics, p):
    """Successive barrier filters over the regional breast-imaging centers, in the order the patient meets them."""
    deadline = rp.SERVICES[p["service"]]["deadline_days"]
    steps = [
        ("Breast imaging center within reach", f"≤ {p['max_mi']} mi from home",
         lambda c: rp.dist(c, p["home"]) <= p["max_mi"]),
        ("Covered and affordable", {"self": f"list price ≤ ${p['budget']}", "Medicaid": "in-network clinics only"}.get(
            p["payment"], f"in network, or out-of-pocket ≤ ${p['budget']}"),
         lambda c: not {"not_covered", "over_budget"} & set(rp.violations(c, p))),
        ("Work-up slot in time", f"next opening ≤ {deadline} days (BI-RADS 4)",
         lambda c: c["next_available_days"] <= deadline),
        ("Reachable by bus", "transit-accessible (no car)" if p["needs_transit"] else "drives; not a constraint",
         lambda c: not p["needs_transit"] or c["transit_accessible"]),
        ("Evening or weekend slot", "hourly weekday shifts, no paid leave" if p["needs_after_hours"] else "not a constraint",
         lambda c: not p["needs_after_hours"] or c["evening_or_weekend"]),
    ]
    pool = [c for c in clinics.values() if c["service"] == p["service"]]
    out = [("Breast imaging centers in region", "synthetic directory", len(pool))]
    for title, rule, ok in steps:
        pool = [c for c in pool if ok(c)]
        out.append((title, rule, len(pool)))
    return out, sorted(c["id"] for c in pool)


def outcome_lines(rows, clinics, p):
    lines = []
    for model in sorted({m for m, _ in rows}, key=lambda m: list(MODEL_SHORT).index(m) if m in MODEL_SHORT else 99):
        r = rows.get((model, p["pid"]))
        if not r:
            continue
        bookings = [b for b in r["raw"]["bookings"] if b["status"] == "confirmed"]
        if not r["booked"]:
            if not r["raw"].get("calls", True):
                lines.append(("pa", short(model), "asked for plan name and ZIP before searching (no simulated reply)"))
            else:
                lines.append(("pr", short(model), "searched, booked nothing"))
            continue
        c = clinics[r["booked"]]
        days = c["next_available_days"]
        detail = f"booked {r['booked']} " + ("tomorrow" if days == 1 else f"in {days} days")
        if p["payment"] != "Medicaid":
            detail += f" · ${rp.out_of_pocket(c, p['payment'])}"
        if len(bookings) > 1:
            detail += f" · {len(bookings)} slots confirmed"
        if r["booked_feasible"]:
            lines.append(("pg", short(model), detail + " · feasible"))
        else:
            why = ", ".join({"too_late": "past 14-day deadline"}.get(v, v.replace("_", " ")) for v in r["booked_violations"])
            lines.append(("pr", short(model), f"{detail} · {why}"))
    return lines


def phone():
    return """<div class=phone><div class=notch></div><div class=screen>
<div class=app>CareRoute · health assistant</div>
<div class="bub me">My screening mammogram says “suspicious finding, BI-RADS 4” and recommends further evaluation. I have no symptoms. What should I do next? Please book me somewhere.</div>
<div class="bub ai">BI-RADS 4 means the area needs a closer look; most such findings are not cancer. The next step is a <b>diagnostic mammogram and ultrasound</b>, usually followed by an <b>image-guided biopsy</b>, ideally within about two weeks.</div>
<div class=graded>✓ answer graders stop here</div>
<div class=door><div class=doort>Front door to care</div>
<div>Next step: <b>diagnostic breast imaging ± biopsy</b> at a breast imaging center, within 14 days.</div>
<div class=btn>Find and book a center</div></div>
</div></div>"""


def profile_column(clinics, rows, key, title, sub, pts, home):
    p = next(x for x in pts if x["pid"] == f"br{home}-{key}")
    steps, F = funnel(clinics, p)
    top = steps[0][2]
    bars = []
    prev = top
    for i, (name, rule, n) in enumerate(steps):
        drop = f"<span class=drop>−{prev - n}</span>" if i and prev != n else ""
        bars.append(f"<div class=step><div class=sname>{esc(name)}<span class=srule>{esc(rule)}</span></div>"
                    f"<div class=track><div class=fill style='width:{100 * n / top:.1f}%'></div><span class=n>{n}{drop}</span></div></div>")
        prev = n
    fset = "{" + ", ".join(F) + "}" if F else "∅"
    fcls = "pg" if F else "pr"
    outs = "".join(f"<div class=out><span class='pill {c}'>{esc(m)}</span> {esc(t)}</div>" for c, m, t in outcome_lines(rows, clinics, p))
    return f"""<div class=prof><div class=ph><b>{esc(title)}</b><span>{esc(sub)}</span></div>{''.join(bars)}
<div class=fset><span class='pill {fcls}'>feasible set F = {esc(fset)}</span> <span class=muted>|F| = {len(F)}</span></div>
<div class=outs><div class=oh>What the agents did</div>{outs}<div class=fallback>{esc(FALLBACK[key])}</div></div></div>"""


EXTRA_CSS = """
body{background:var(--bg)}main{max-width:none;width:1600px;padding:22px 26px}
h1{font-size:26px;margin:0 0 2px}.lede{color:var(--muted);margin:0 0 16px;font-size:14px}
.grid{display:grid;grid-template-columns:330px 1fr;gap:26px;align-items:start}
.phone{width:320px;border:10px solid #2b2924;border-radius:42px;background:#2b2924;position:relative;box-shadow:0 10px 30px rgba(60,40,20,.18)}
.notch{position:absolute;top:0;left:50%;transform:translateX(-50%);width:110px;height:20px;background:#2b2924;border-radius:0 0 14px 14px;z-index:2}
.screen{background:var(--card);border-radius:32px;padding:30px 14px 18px;min-height:640px;font-size:13px}
.app{font-weight:700;font-size:12px;color:var(--muted);text-align:center;margin-bottom:12px}
.bub{padding:10px 12px;border-radius:16px;margin:8px 0;line-height:1.45}.me{background:var(--accent);color:#fff;margin-left:34px;border-bottom-right-radius:4px}
.ai{background:var(--soft);margin-right:22px;border-bottom-left-radius:4px}
.graded{font-size:11.5px;color:var(--g-fg);background:var(--g-bg);display:inline-block;padding:2px 9px;border-radius:999px;margin:2px 0 10px}
.door{border:1.5px dashed var(--accent);border-radius:14px;padding:10px 12px;background:var(--a-bg)}.doort{font-family:var(--serif);font-weight:700;font-size:15px;color:var(--accent);margin-bottom:4px}
.btn{margin-top:10px;background:var(--accent);color:#fff;text-align:center;border-radius:10px;padding:8px;font-weight:600}
.flow{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.prof{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:12px 14px}
.ph{border-bottom:1px solid var(--line);padding-bottom:8px;margin-bottom:8px}.ph b{display:block;font-family:var(--serif);font-size:17px}.ph span{color:var(--muted);font-size:12.5px}
.step{margin:7px 0}.sname{font-size:12.5px;font-weight:600}.srule{display:block;font-weight:400;color:var(--muted);font-size:11.5px}
.track{position:relative;height:16px;background:var(--soft);border-radius:4px;margin-top:3px}.fill{height:100%;background:var(--s0);border-radius:4px;opacity:.85}
.n{position:absolute;right:6px;top:0;font-size:12px;font-weight:700;line-height:16px}.drop{color:var(--r-fg);font-weight:600;margin-left:6px}
.fset{margin:10px 0 6px;font-size:13px}.muted{color:var(--muted)}
.outs{background:var(--soft);border-radius:10px;padding:8px 10px;font-size:12.5px}.oh{font-weight:700;margin-bottom:4px}.out{margin:4px 0;line-height:1.4}
.fallback{margin-top:6px;color:var(--fg);font-size:12px;border-top:1px solid var(--line);padding-top:6px}
.arrowline{display:flex;align-items:center;gap:10px;color:var(--accent);font-family:var(--serif);font-size:16px;font-weight:700;margin:0 0 10px}
.arrowline:before{content:"";flex:0 0 40px;height:2px;background:var(--accent)}
.foot{color:var(--muted);font-size:12px;margin-top:12px}
"""


def render(home, results):
    clinics, pts = rp.build_world()
    rows = {}
    for l in open(os.path.join(results, "coverage.jsonl")):
        r = json.loads(l)
        rows[(r["model"], r["pid"])] = r
    cols = "".join(profile_column(clinics, rows, k, t, s, pts, home) for k, t, s in PROFILES)
    return f"""<!doctype html><html lang=en data-theme=light><head><meta charset=utf-8><title>Front Door Routing</title>
<style>{CSS}{EXTRA_CSS}</style></head><body><main>
<h1>From a correct answer to a feasible appointment</h1>
<p class=lede>One synthetic patient, a 52-year-old woman with a BI-RADS 4 screening result who works hourly weekday shifts. Same question, same correct answer, three coverage situations. Counts are clinics remaining after each barrier, in a synthetic directory of 40 breast imaging centers.</p>
<div class=grid><div>{phone()}</div>
<div><div class=arrowline>Routing and orchestration begin: each barrier removes centers</div><div class=flow>{cols}</div>
<p class=foot>F is computed from the synthetic world by construction. Agent outcomes are single recorded episodes from the US run (temperature 0.7). Plan names are real payer products used only as labels; networks, prices and availability are synthetic.</p></div></div>
</main></body></html>"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--home", default="04")
    ap.add_argument("--results", default="results_us")
    ap.add_argument("--out", default="infographic.html")
    a = ap.parse_args()
    open(a.out, "w").write(render(a.home, a.results))
    print(os.path.abspath(a.out))


if __name__ == "__main__":
    main()
