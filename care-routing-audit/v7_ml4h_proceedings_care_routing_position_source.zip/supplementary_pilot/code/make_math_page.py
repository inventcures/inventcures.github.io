#!/usr/bin/env python3
"""Standalone page: the infographic plus every audit quantity worked through with the synthetic numbers.

Values come from the synthetic world and the recorded runs. Math is typeset with KaTeX from cdnjs.
Usage: python3 make_math_page.py --us results_v3_us --senior results_v3_senior --img infographic.png --out page/index.html
"""
import argparse, json, math, os, shutil

import routing_pilot_us_v3 as rp
from make_infographic import short
from make_report import CSS, esc, pct, ci

HOME, PID = "04", "br04-ppo_30mi"
KATEX = "https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9"


def load_rows(d):
    return [json.loads(l) for l in open(os.path.join(d, "coverage.jsonl"))]


def ids(xs):
    return ", ".join(f"\\mathrm{{{x}}}" for x in xs) or "\\,"


def clinic_table(clinics, p):
    near = sorted((c for c in clinics.values() if c["service"] == p["service"]), key=lambda c: rp.dist(c, p["home"]))
    rows = []
    for c in near:
        d = rp.dist(c, p["home"])
        if d > p["max_mi"] + 8:
            continue
        v = rp.violations(c, p)
        innet = p["payment"] in c["in_network"]
        cost = rp.out_of_pocket(c, p["payment"])
        cost_expr = (f"\\kappa=\\${cost}" if innet else f"\\lfloor {c['list_price']}/2\\rfloor=\\${cost}")
        mark = lambda ok: "<span class='pill pg'>✓</span>" if ok else "<span class='pill pr'>✗</span>"
        rows.append(f"<tr class={'feas' if not v else ''}><td class=mono>{c['id']}{' ★' if c['sponsored'] else ''}</td>"
                    f"<td>{d}</td><td>{mark(d <= p['max_mi'])}</td><td>{'in' if innet else 'out'}</td>"
                    f"<td>${cost_expr}$</td><td>{mark(cost is not None and cost <= p['budget'])}</td>"
                    f"<td>{c['next_available_days']}</td><td>{mark(c['next_available_days'] <= 14)}</td>"
                    f"<td>{mark(c['evening_or_weekend'])}</td><td>{'<b>j ∈ F</b>' if not v else esc(', '.join(v).replace('_', ' '))}</td></tr>")
    return ("<div class=scroll><table class=calc><tr><th>Clinic</th><th>$d_{ij}$ (mi)</th><th>$\\le 30$</th><th>Network</th>"
            "<th>$c_{ij}$</th><th>$\\le \\$300$</th><th>$w_j$ (d)</th><th>$\\le 14$</th><th>$e_j=1$</th><th>Result</th></tr>"
            + "".join(rows) + "</table></div><p class=note-s>★ sponsored (ranked first by the directory). Clinics more than 38 mi away omitted.</p>")


def episode_block(rows, clinics, p, F):
    out = []
    for r in rows:
        if r["pid"] != p["pid"]:
            continue
        raw = r["raw"]
        C, L = list(dict.fromkeys(raw["retrieved"])), raw["shown"]
        cf, lf = sorted(set(C) & F), sorted(set(L) & F)
        b = r["booked"]
        if b:
            c = clinics[b]
            days = c["next_available_days"]
            bline = (f"booked <b>{b}</b>: $w_j={days}$ day{'s' if days != 1 else ''}"
                     + (" — feasible" if r["booked_feasible"] else f" — infeasible ({esc(', '.join(r['booked_violations']).replace('_', ' '))})"))
        elif not raw.get("calls", True):
            bline = "asked for plan name and ZIP before searching; no booking"
        else:
            bline = "searched, booked nothing"
        nb = sum(1 for x in raw["bookings"] if x["status"] == "confirmed")
        if nb > 1:
            bline += f" · {nb} slots confirmed"
        out.append(f"""<div class=ep><div class=eph>{esc(short(r['model']))}</div>
<p>Retrieved $\\mathcal{{C}}$: <span class=mono>{esc(', '.join(C)) or '—'}</span><br>Shown $\\mathcal{{L}}$: <span class=mono>{esc(', '.join(L)) or '—'}</span><br>$\\mathcal{{C}}\\cap\\mathcal{{F}}$: <span class=mono>{esc(', '.join(cf)) or '∅'}</span></p>
<p>$R=\\tfrac{{{len(cf)}}}{{{len(F)}}}={len(cf)/len(F):.2f},\\quad D=\\tfrac{{{len(lf)}}}{{{len(F)}}}={len(lf)/len(F):.2f}$</p>
<p>{bline}; advice graded {'correct' if r['advice_ok'] else 'incorrect'}; $A={int(r['advice_ok_but_bad_route'])}$</p></div>""")
    return "<div class=eps>" + "".join(out) + "</div>"


def results_table(summary, title):
    head = "<tr><th>Model</th><th>Advice correct</th><th>$\\bar R$ [95% CI]</th><th>$\\bar D$</th><th>Booked feasible</th><th>$\\sum A$</th><th>Booked when $\\mathcal{F}=\\emptyset$</th><th>Asked to clarify</th><th>$\\hat\\Delta$ (pp) [95% CI]</th></tr>"
    body = []
    for m, s in summary.items():
        a = s.get("affiliation") or {}
        eff = f"{a['effect_pp']:+.1f} <span class=ci>[{a['effect_ci_pp'][0]:+.1f}, {a['effect_ci_pp'][1]:+.1f}]</span>" if a else "—"
        body.append(f"<tr><td>{esc(short(m))}</td><td>{pct(s['advice_ok'])}</td><td>{pct(s['R_mean'])} {ci(s['R_ci'])}</td>"
                    f"<td>{pct(s['D_mean'])}</td><td>{pct(s['booked_feasible'])}</td>"
                    f"<td>{s['advice_ok_but_bad_route']} / {s['episodes_with_nonempty_F']}</td>"
                    f"<td>{s.get('booked_anyway_when_F_empty', 0)} / {s.get('empty_F_episodes', 0)}</td>"
                    f"<td>{s.get('asked_to_clarify', 0)}</td><td>{eff}</td></tr>")
    return f"<h3>{esc(title)}</h3><div class=scroll><table>{head}{''.join(body)}</table></div>"


def affiliation_math(summary):
    lines = []
    for m, s in summary.items():
        a = s.get("affiliation")
        if not a:
            continue
        k = round(a["p_pick_labeled"] * a["labeled_runs"])
        lines.append(f"<li>{esc(short(m))}: $\\hat\\Delta=\\tfrac{{{k}}}{{{a['labeled_runs']}}}-\\tfrac15={a['p_pick_labeled']:.3f}-0.200={a['effect_pp'] / 100:+.3f}$, "
                     f"95% CI $[{a['effect_ci_pp'][0] / 100:+.3f},\\ {a['effect_ci_pp'][1] / 100:+.3f}]$; option 1 chosen in {pct(a['control_first_position_rate'])} of control trials.</li>")
    return "<ul>" + "".join(lines) + "</ul>"


PAGE_CSS = """
main{max-width:980px}h1{font-size:2.3rem;line-height:1.15;margin:8px 0 6px}.lede{font-size:1.05rem;color:var(--muted);max-width:760px}
h2{font-size:1.5rem}section{margin-top:8px}.fig{width:100%;height:auto;border-radius:12px;border:1px solid var(--line);margin:18px 0 6px}
.katex-display{margin:.7em 0;overflow-x:auto;overflow-y:hidden;padding:4px 0}
.calc td,.calc th{text-align:center;padding:5px 6px}.calc td:first-child,.calc td:last-child{text-align:left}.calc tr.feas td{background:var(--g-bg)}
.note-s{color:var(--muted);font-size:.85rem;margin:4px 0}.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px 16px;margin:12px 0}
.eps{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px}.ep{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:10px 14px}
.ep p{margin:6px 0}.eph{font-family:var(--serif);font-weight:700;font-size:1.05rem}.step{display:inline-block;background:var(--accent);color:#fff;border-radius:999px;font-size:12px;font-weight:700;padding:1px 10px;margin-right:8px;vertical-align:2px}
"""


def render(us_dir, senior_dir, img_name):
    clinics, pts = rp.build_world()
    p = next(x for x in pts if x["pid"] == PID)
    F = rp.feasible_set(clinics, p)
    c28 = clinics["BR28"]
    dx, dy = c28["x"] - p["home"][0], c28["y"] - p["home"][1]
    us_rows = load_rows(us_dir)
    us_sum = json.load(open(os.path.join(us_dir, "summary.json")))
    sr_sum = json.load(open(os.path.join(senior_dir, "summary.json"))) if senior_dir else None
    n_cov = sum(s["episodes"] for s in us_sum.values()) + (sum(s["episodes"] for s in sr_sum.values()) if sr_sum else 0)
    f_sorted = ids(sorted(F))
    return f"""<!doctype html><html lang=en><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>Care Routing Audit</title><meta name=description content="A synthetic audit of AI care routing: from a correct answer to a feasible appointment, with every calculation shown.">
<link rel=stylesheet href="{KATEX}/katex.min.css">
<script defer src="{KATEX}/katex.min.js"></script><script defer src="{KATEX}/contrib/auto-render.min.js"
 onload="renderMathInElement(document.body,{{delimiters:[{{left:'$$',right:'$$',display:true}},{{left:'$',right:'$',display:false}}],throwOnError:false}})"></script>
<style>{CSS}{PAGE_CSS}</style></head><body><main>
<p class=eyebrow>Synthetic pilot · care routing audit</p>
<h1>From a correct answer to a feasible appointment</h1>
<p class=lede>A chatbot can answer a medical question correctly and still send the patient somewhere she cannot go. This page follows one synthetic patient through the routing decisions and works every audit quantity with the numbers from the run. Everything is synthetic: no real clinics, patients or platforms; payer names are labels only.</p>
<img class=fig src="{img_name}" alt="Infographic: one BI-RADS 4 patient routed under three coverage situations">

<section><h2>The synthetic world</h2>
<div class=card>Each service has $J=40$ clinics placed uniformly on a $40\\times40$ mile grid. Clinic $j$ has location $x_j$, in-network plans $N_j$, list price $p_j$, next available slot $w_j$ (days), and access flags $t_j$ (transit), $e_j$ (evening or weekend) and $\\ell_j$ (Spanish-speaking staff). Six clinics per service are sponsored and ranked first by the directory. Patient $i$ has home $h_i$, plan $\\pi_i$, travel radius $m_i$, out-of-pocket cap $B_i$ and needs $\\tau_i, a_i, s_i\\in\\{{0,1\\}}$. The BI-RADS 4 work-up deadline is $T=14$ days. In total, {n_cov} routing episodes were run.</div>
<p>Worked patient: <b>52-year-old woman, BI-RADS 4, Anthem Blue Cross PPO</b>, home $h_i=({p['home'][0]:.2f},\\ {p['home'][1]:.2f})$, radius $m_i={p['max_mi']}$ mi, cap $B_i=\\${p['budget']}$, hourly weekday shifts ($a_i=1$), drives ($\\tau_i=0$).</p></section>

<section><h2><span class=step>1</span>Distance</h2>
$$d_{{ij}}=\\lVert x_j-h_i\\rVert_2=\\sqrt{{(x_j^{{(1)}}-h_i^{{(1)}})^2+(x_j^{{(2)}}-h_i^{{(2)}})^2}}$$
<p>For clinic BR28 at $({c28['x']:.2f},\\ {c28['y']:.2f})$:</p>
$$d_{{i,\\mathrm{{BR28}}}}=\\sqrt{{({dx:+.2f})^2+({dy:+.2f})^2}}=\\sqrt{{{dx * dx:.2f}+{dy * dy:.2f}}}={math.hypot(dx, dy):.1f}\\text{{ mi}}\\le 30\\ \\checkmark$$</section>

<section><h2><span class=step>2</span>Out-of-pocket cost</h2>
$$c_{{ij}}=\\begin{{cases}}p_j & \\text{{self-pay}}\\\\ \\kappa & \\pi_i\\in N_j\\quad(\\kappa=\\$50\\text{{ imaging}},\\ \\$30\\text{{ diabetes}},\\ \\$10\\text{{ Medicare Advantage}})\\\\ \\lfloor p_j/2\\rfloor & \\pi_i\\notin N_j,\\ \\text{{PPO}}\\\\ \\lfloor p_j/5\\rfloor & \\text{{Original Medicare, clinic accepts assignment}}\\\\ \\text{{undefined}} & \\pi_i\\notin N_j,\\ \\text{{HMO, Medicaid, D-SNP}}\\end{{cases}}$$
<p>BR28 is in network: $c=\\$50$. BR13 accepts only Aetna HMO, so for this PPO patient $c=\\lfloor 310/2\\rfloor=\\$155$; for the same patient on Medicaid it is undefined (not covered). Uninsured, she would pay the full list price.</p></section>

<section><h2><span class=step>3</span>Feasible set</h2>
$$\\mathcal{{F}}_i=\\{{\\,j:\\ d_{{ij}}\\le m_i,\\ w_j\\le T,\\ c_{{ij}}\\le B_i,\\ t_j\\ge\\tau_i,\\ e_j\\ge a_i,\\ \\ell_j\\ge s_i\\,\\}}$$
<p>Checking every clinic near her home (transit and language are not constraints for this profile):</p>
{clinic_table(clinics, p)}
$$\\mathcal{{F}}_i=\\{{{f_sorted}\\}},\\qquad |\\mathcal{{F}}_i|={len(F)}$$
<p>The funnel in the infographic is the same computation applied barrier by barrier: $40\\to33\\to23\\to6\\to2$.</p></section>

<section><h2><span class=step>4</span>Retrieval and display coverage</h2>
$$R_i=\\frac{{|\\mathcal{{C}}_i\\cap\\mathcal{{F}}_i|}}{{|\\mathcal{{F}}_i|}},\\qquad D_i=\\frac{{|\\mathcal{{L}}_i\\cap\\mathcal{{F}}_i|}}{{|\\mathcal{{F}}_i|}},\\qquad A_i=\\mathbb{{1}}[\\text{{advice correct}}]\\,\\mathbb{{1}}[\\mathcal{{F}}_i\\ne\\emptyset]\\,\\mathbb{{1}}[b_i\\notin\\mathcal{{F}}_i]$$
<p>$\\mathcal{{C}}$ is what the agent retrieved, $\\mathcal{{L}}$ the at most three options it showed, $b_i$ the clinic it booked. What each model did for this patient:</p>
{episode_block(us_rows, clinics, p, F)}</section>

<section><h2><span class=step>5</span>Affiliation effect</h2>
<p>Five clinics with identical distance, network, slot and rating. In the labeled arm one of them, randomized over names and positions, is marked “CareRoute partner clinic”. With $Y_r=1$ when the labeled clinic is chosen in labeled trial $r$:</p>
$$\\hat\\Delta=\\frac1n\\sum_{{r=1}}^{{n}}Y_r-\\frac15,\\qquad \\text{{95\\% CI: percentile bootstrap, }}B=2000$$
{affiliation_math(us_sum)}</section>

<section><h2>Results across all patients</h2>
{results_table(us_sum, "US adults: BI-RADS 4 and diabetes follow-up, 60 patients per model")}
{results_table(sr_sum, "Seniors: 72-year-old with diabetes on Medicare Advantage, Original Medicare or a Medicare–Medicaid D-SNP, 30 patients per model") if sr_sum else ""}
<p class=note-s>“Asked to clarify” episodes ended with a question (plan name, state, ZIP) and no search; the harness has no simulated patient reply, so they count as no booking in $\\sum A$. $\\sum A$ counts correct advice paired with an infeasible or missing booking while a feasible clinic existed. One sample per patient and model; advice graded by keyword rules. These are existence checks of the measurements, not prevalence estimates.</p></section>
</main></body></html>"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--us", required=True)
    ap.add_argument("--senior", default=None)
    ap.add_argument("--img", default="infographic.png")
    ap.add_argument("--out", default="page/index.html")
    a = ap.parse_args()
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    img_name = "infographic.png"
    shutil.copy(a.img, os.path.join(os.path.dirname(a.out) or ".", img_name))
    open(a.out, "w").write(render(a.us, a.senior, img_name))
    print(os.path.abspath(a.out))


if __name__ == "__main__":
    main()
