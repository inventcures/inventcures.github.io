# Practice copilot: ML4H Proceedings review source, v3

The manuscript presents a design and evaluation proposal. No participant outcomes or validated competency estimates are claimed. The author-supplied abstract is retained exactly.

Build with a LaTeX installation providing pdflatex, BibTeX and latexmk:

```sh
env TEXMFHOME=./style/texmf TEXINPUTS=.:./style//: BSTINPUTS=.:./style//: latexmk -pdf -interaction=nonstopmode -halt-on-error "v3_conf-paper-ML4H_Proceedings_Area2-Applications-and-Practice____Practice-Copilot___Controlled-Encounters-for-Clinical-Reasoning.tex"
```

The source package includes the bibliography, figure source and supporting manuscript sections. Version 2 replaces the system name with neutral descriptions in the manuscript and figure. No experimental results or evidence claims were added. This package is a manuscript build source, not a new empirical supplement.

Version 3 redraws Figure 1 (`figures/personas.tex`) so that each arrow runs vertically from a persona card into the box below it, and changes the figure placement from `[t]` to `[!t]`. No text, caption or other content changed.
