# Proposed evaluation protocol

This is a study-design artifact, not a preregistration or a completed experiment. All numerical thresholds and sample sizes must be specified prospectively with investigators and appropriate institutional review.

## Study A: case and cue fidelity

Use clinician-reviewed synthetic cases and native-speaker-reviewed phrasing. Test fixed facts, paraphrased questions, clarification, disclosure prerequisites, incompatible requests, interruptions and prompt-injection attempts. Record clinical contradictions and disclosure errors per opportunity. Evaluate actual delivered audio rather than the requested emotion. Independent reviewers assess plausibility and cue availability without forced agreement. Neutral variants quantify false emotional attribution. Exclude a cue from learner scoring when availability cannot be established.

## Study B: evidence and scoring audit

Create independently annotated encounters, with strong, weak, verbose, premature-closure, unsafe and clinically competent but communicatively weak profiles. Expert labels should be created independently of the model under evaluation. Partition by case family and learner, not utterance. Report attribution precision/recall, false credit, missed credit, ordinal agreement and domain-rating absolute agreement with uncertainty. Patient/caregiver perspectives contribute to defining appropriate communication; no one rater is unquestionable ground truth. Analyze ASR corrections separately.

## Study C: feedback interaction

Compare evidence-linked feedback with summary feedback using identical assessments. Seed known transcription and cue-availability errors in a consented evaluation. Measure detection, correction, downstream removal of erroneous recommendations, time, workload and understanding. Avoid treating repeated interface actions as independent participants. Interview participants about authority, privacy, ambiguity and their interpretation of progress, using an explicit qualitative method established before collection.

## Study D: learning, retention and transfer

Compare teaching conditions matched for practice time and feedback access. Measure baseline performance, supported practice, independent novel-case performance and delayed unassisted performance. A human standardized-patient encounter can provide an additional transfer endpoint. Prespecify the primary endpoint and delay; determine sample size using meaningful effects, variance and clustering. Counterbalance case order and repeated exposure. Distinguish transfer to a new voice, a new phrase, a new case family and a human encounter. No amount of simulated success guarantees flawless clinical practice.

## Stopping or narrowing rules

Pause affected cases for clinical contradictions or unauthorized disclosure. Remove voice-dependent scoring when a cue is not delivered. Remove automated dimensions that cannot be attributed reliably to evidence. If expressive speech improves preference but not independent performance, report that difference. If feedback only improves repeated-case performance, do not claim transfer. If subgroup evidence is too sparse, report uncertainty rather than declaring fairness.
